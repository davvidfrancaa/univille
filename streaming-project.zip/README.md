# Streaming Project (skeleton)
Este repositório contém um projeto Spring Boot mínimo com entidades JPA, repositórios e um DataLoader para popular dados.

Como usar:
- `mvn clean package`
- `mvn spring-boot:run`
- H2 console: http://localhost:8080/h2-console (jdbc:h2:mem:streamdb)

Arquivos inclusos: código-fonte Java, application.properties e um diagrama PlantUML (diagrama.puml).
