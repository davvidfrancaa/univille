package com.example.streaming.repository;
import com.example.streaming.entity.Avaliacao;
public interface AvaliacaoRepository extends org.springframework.data.jpa.repository.JpaRepository<Avaliacao, Long>{}
