package com.example.streaming.repository;

import com.example.streaming.entity.Video;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface VideoRepository extends org.springframework.data.jpa.repository.JpaRepository<Video, Long> {
    @Query("SELECT v FROM Video v WHERE LOWER(v.titulo) LIKE LOWER(CONCAT('%',:term,'%')) ORDER BY v.titulo ASC")
    List<Video> searchByTituloOrdered(@Param("term") String term);

    List<Video> findByCategoriaNomeOrderByTituloAsc(String categoriaNome);

    @Query("SELECT v FROM Video v LEFT JOIN v.avaliacoes a GROUP BY v.id ORDER BY COALESCE(AVG(a.nota),0) DESC")
    List<Video> findTopRated(Pageable pageable);

    @Query("SELECT v FROM Video v LEFT JOIN v.visualizacoes vis GROUP BY v.id ORDER BY COUNT(vis) DESC")
    List<Video> findTopWatched(Pageable pageable);
}
