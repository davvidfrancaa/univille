package com.example.streaming.repository;
import com.example.streaming.entity.Visualizacao;
public interface VisualizacaoRepository extends org.springframework.data.jpa.repository.JpaRepository<Visualizacao, Long>{}
