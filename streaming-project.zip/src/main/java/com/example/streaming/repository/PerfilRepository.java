package com.example.streaming.repository;
import com.example.streaming.entity.Perfil;
public interface PerfilRepository extends org.springframework.data.jpa.repository.JpaRepository<Perfil, Long>{}
