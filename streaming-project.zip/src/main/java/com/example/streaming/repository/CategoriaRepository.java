package com.example.streaming.repository;
import com.example.streaming.entity.Categoria;
public interface CategoriaRepository extends org.springframework.data.jpa.repository.JpaRepository<Categoria, Long>{}
