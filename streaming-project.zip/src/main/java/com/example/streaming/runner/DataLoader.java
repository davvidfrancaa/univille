package com.example.streaming.runner;

import com.example.streaming.entity.*;
import com.example.streaming.repository.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.data.domain.PageRequest;
import java.time.LocalDateTime;
import java.util.Arrays;

@Component
public class DataLoader implements CommandLineRunner {
    private final UsuarioRepository usuarioRepo;
    private final PerfilRepository perfilRepo;
    private final CategoriaRepository categoriaRepo;
    private final VideoRepository videoRepo;
    private final VisualizacaoRepository visualRepo;
    private final AvaliacaoRepository avalRepo;

    public DataLoader(UsuarioRepository usuarioRepo, PerfilRepository perfilRepo,
                      CategoriaRepository categoriaRepo, VideoRepository videoRepo,
                      VisualizacaoRepository visualRepo, AvaliacaoRepository avalRepo) {
        this.usuarioRepo = usuarioRepo;
        this.perfilRepo = perfilRepo;
        this.categoriaRepo = categoriaRepo;
        this.videoRepo = videoRepo;
        this.visualRepo = visualRepo;
        this.avalRepo = avalRepo;
    }

    @Override
    public void run(String... args) throws Exception {
        Usuario u1 = new Usuario(); u1.setNome("Carlos"); u1.setEmail("carlos@ex.com"); u1.setSenha("123"); u1.setDataCadastro(LocalDateTime.now());
        Usuario u2 = new Usuario(); u2.setNome("Mariana"); u2.setEmail("mari@ex.com"); u2.setSenha("123"); u2.setDataCadastro(LocalDateTime.now());
        usuarioRepo.saveAll(Arrays.asList(u1, u2));

        Perfil p1 = new Perfil(); p1.setNomePerfil("Carlos-Principal"); p1.setUsuario(u1);
        Perfil p2 = new Perfil(); p2.setNomePerfil("Mari-Principal"); p2.setUsuario(u2);
        perfilRepo.saveAll(Arrays.asList(p1, p2));

        Categoria c1 = new Categoria(); c1.setNome("Documentário");
        Categoria c2 = new Categoria(); c2.setNome("Ação");
        Categoria c3 = new Categoria(); c3.setNome("Missão");
        categoriaRepo.saveAll(Arrays.asList(c1,c2,c3));

        Video v1 = new Video(); v1.setTitulo("Missão Estelar"); v1.setDescricao("Exploração..."); v1.setDuracao(3600); v1.setCategoria(c3);
        Video v2 = new Video(); v2.setTitulo("Missão Resgate"); v2.setDescricao("Resgate em..."); v2.setDuracao(2500); v2.setCategoria(c3);
        Video v3 = new Video(); v3.setTitulo("Corrida Noturna"); v3.setDescricao("Ação pura"); v3.setDuracao(1800); v3.setCategoria(c2);
        Video v4 = new Video(); v4.setTitulo("História do Universo"); v4.setDescricao("Doc"); v4.setDuracao(5400); v4.setCategoria(c1);
        videoRepo.saveAll(Arrays.asList(v1,v2,v3,v4));

        visualRepo.save(new Visualizacao(null, p1, v1, LocalDateTime.now().minusDays(2), 1200));
        visualRepo.save(new Visualizacao(null, p1, v2, LocalDateTime.now().minusDays(1), 2000));
        visualRepo.save(new Visualizacao(null, p2, v1, LocalDateTime.now().minusHours(3), 3600));
        visualRepo.save(new Visualizacao(null, p2, v3, LocalDateTime.now().minusHours(2), 1500));
        visualRepo.save(new Visualizacao(null, p1, v1, LocalDateTime.now().minusDays(1), 1800));
        visualRepo.save(new Visualizacao(null, p1, v1, LocalDateTime.now().minusDays(3), 900));

        avalRepo.save(new Avaliacao(null, p1, v1, 5, "Excelente"));
        avalRepo.save(new Avaliacao(null, p2, v1, 4, "Muito bom"));
        avalRepo.save(new Avaliacao(null, p1, v2, 3, "OK"));
        avalRepo.save(new Avaliacao(null, p2, v3, 5, "Top"));

        System.out.println("Buscar por titulo 'Missão': " + videoRepo.searchByTituloOrdered("Missão"));
        System.out.println("Vídeos categoria 'Missão': " + videoRepo.findByCategoriaNomeOrderByTituloAsc("Missão"));
        System.out.println("Top rated: " + videoRepo.findTopRated(PageRequest.of(0,10)));
        System.out.println("Top watched: " + videoRepo.findTopWatched(PageRequest.of(0,10)));
        System.out.println("Usuario que mais assistiu: " + usuarioRepo.findTopUsersByViews(PageRequest.of(0,1)));
    }
}
