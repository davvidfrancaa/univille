package com.example.streaming.entity;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name="video")
public class Video {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable=false, unique=true)
    private String titulo;
    @Column(length=1000)
    private String descricao;
    @Column(nullable=false)
    private Integer duracao;
    @ManyToOne
    @JoinColumn(name="categoria_id", nullable=false)
    private Categoria categoria;
    @OneToMany(mappedBy="video", cascade = CascadeType.ALL)
    private List<Visualizacao> visualizacoes;
    @OneToMany(mappedBy="video", cascade = CascadeType.ALL)
    private List<Avaliacao> avaliacoes;
    public Video(){}
    // getters/setters
    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}
    public String getTitulo(){return titulo;}
    public void setTitulo(String titulo){this.titulo=titulo;}
    public String getDescricao(){return descricao;}
    public void setDescricao(String descricao){this.descricao=descricao;}
    public Integer getDuracao(){return duracao;}
    public void setDuracao(Integer duracao){this.duracao=duracao;}
    public Categoria getCategoria(){return categoria;}
    public void setCategoria(Categoria categoria){this.categoria=categoria;}
    @Override
    public String toString(){return "Video{"+id+","+titulo+"}";}
}
